math_module = require("./mathlib")();

math_module.add(12, 23)
math_module.multiply(12, 10)
math_module.square(12)
math_module.random(12, 23)